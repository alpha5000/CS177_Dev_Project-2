import wave
import p2lib

def copyFile():




def combine():
    
    
      
def change_volume():
    
    


def silence():
    

    
    
    
def main():
    while 1:
        print("Please Select a function")
        print("1 = Audio File Merge")
        print("2 = Adjust Volume")
        print("3 = Generate Silence")
        print("4 = Copy File")
        
    #Here you should read imput from the user and choose an appropriate course of action



main()
